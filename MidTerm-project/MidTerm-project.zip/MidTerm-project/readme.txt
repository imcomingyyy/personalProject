square:
https://www.123rf.com/photo_41646890_tiananmen-square-and-gate-of-heavenly-peace-the-entrance-to-the-palace-museum-in-beijing-gugun-tiana.html
https://en.wikipedia.org/wiki/Tiananmen_Square

pic
https://pixabay.com/photos/background-panorama-sunset-dawn-3104413/
https://goshenfarm.org/homepage-hero-background/
https://www.dctc.edu/

https://www.neverendingvoyage.com/best-places-to-visit-in-japan/